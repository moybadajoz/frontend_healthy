<template>
  <user-login />
</template>

<script>
export default {
  name: 'IndexPage',
  auth: false,
  layout: 'login'
}
</script>
