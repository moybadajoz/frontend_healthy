<template>
  <div />
</template>

<script>

export default {
  layout: 'dashboard',
  auth: true
}
</script>
