import Vue from 'vue'
import UserLogin from '@/components/ui/UserLogin.vue'

Vue.component('UserLogin', UserLogin)
